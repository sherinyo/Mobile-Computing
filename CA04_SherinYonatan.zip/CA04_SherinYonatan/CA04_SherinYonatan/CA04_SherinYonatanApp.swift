//
//  CA04_SherinYonatanApp.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct CA04_SherinYonatanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
