//
//  MovieStore.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import Foundation
import Combine

final class MovieStore: ObservableObject {
    @Published var movies: [Movie] = []
    @Published var selectedMovieID: UUID? = nil
    
    init(sampleData: Bool = true) {
        if sampleData { self.movies = Self.sampleMovies() }
    }
    
    static func sampleMovies() -> [Movie] {
        return [
            Movie(title: "Minions", genre: "Cartoon", year: 2015,
                  posterURL: URL(string: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQF65S0BzPnyy944uqf41gLx_ZbGv0kHRmSL4Kz4oYVBUb_tNP8P1dXPDio_Zs49iNBPPwlNLk"),
                  synopsis: "Evolving from single-celled yellow organisms at the dawn of time, Minions live to serve, but find themselves working for a continual series of unsuccessful masters, from T. Rex to Napoleon. Without a master to grovel for, the Minions fall into a deep depression. But one minion, Kevin, has a plan; accompanied by his pals Stuart and Bob, Kevin sets forth to find a new evil boss for his brethren to follow. Their search leads them to Scarlet Overkill, the world's first-ever super-villainess.", rating: 8.1),
            Movie(title: "Demon Slayer", genre: "Action, Anime", year: 2025,
                  posterURL: URL(string: "https://nos.jkt-1.neo.id/media.cinema21.co.id/movie-images/25DSIC.jpg"),
                  synopsis: "A family is attacked by demons and only two members survive - Tanjiro and his sister Nezuko, who is turning into a demon slowly. Tanjiro sets out to become a demon slayer to avenge his family and cure his sister.", rating: 9.0),
            Movie(title: "Mission: Impossible – The Final Reckoning", genre: "Action/Thriller", year: 2025,
                  posterURL: URL(string: "https://upload.wikimedia.org/wikipedia/id/3/36/Fix_Mission_Impossible_–_The_Final_Reckoning_Poster2.jpg"),
                  synopsis: "Hunt and the IMF pursue a dangerous AI called the Entity that's infiltrated global intelligence. With governments and a figure from his past in pursuit, Hunt races to stop it from forever changing the world.", rating: 7.2),
            Movie(title: "Moana", genre: "Family/Adventure", year: 2016,
                  posterURL: URL(string: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn1.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcTq7M1d9ljrLzBxmn-vxceGdGGgoD8vg6ITrscZYUrHPANgz7-E&psig=AOvVaw1V7KJhJZEakxHa-K-JIXsI&ust=1759468954643000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCPCR_u3ihJADFQAAAAAdAAAAABAE"),
                  synopsis: "An adventurous teenager sails out on a daring mission to save her people. During her journey, Moana meets the once-mighty demigod Maui, who guides her in her quest to become a master way-finder. Together they sail across the open ocean on an action-packed voyage, encountering enormous monsters and impossible odds. Along the way, Moana fulfills the ancient quest of her ancestors and discovers the one thing she always sought: her own identity.", rating: 7.6),
            Movie(title: "The Conjuring: Last Rites", genre: "Horror", year: 2025,
                  posterURL: URL(string: "https://www.google.com/url?sa=i&url=https%3A%2F%2Fencrypted-tbn1.gstatic.com%2Fimages%3Fq%3Dtbn%3AANd9GcR8HacndKbxLjzbyw0Q9_CrYk-pzd4DjZknBV-bGOHukPcpcUie&psig=AOvVaw36RNXTYUEjxlKak1OEsIOH&ust=1759469046139000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCLC_1pjjhJADFQAAAAAdAAAAABAE"),
                  synopsis: "PParanormal investigators Ed and Lorraine Warren take on one last terrifying case involving mysterious entities they must confront.", rating: 8.3),
        ]
    }
}
