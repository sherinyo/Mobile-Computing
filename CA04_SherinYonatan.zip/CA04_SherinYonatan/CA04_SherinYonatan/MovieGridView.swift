//
//  MovieGridView.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieGridView: View {
    @EnvironmentObject var store: MovieStore
    var columns: [GridItem] = [GridItem(.flexible()), GridItem(.flexible())]
    var onCardTap: (Movie) -> Void
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach($store.movies) { $movie in
                    Button(action: { onCardTap(movie) }) {
                        MovieCardView(movie: movie, isFav: $movie.isFav)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding()
        }
    }
}

