//
//  ContentView.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var store = MovieStore()
    @State private var searchText: String = ""
    @State private var gridColumns = 2
    @State private var showOnlyFav = false
    
    // search dan toggle 
    var filteredMovies: [Movie] {
        let searched = searchText.trimmingCharacters(in: .whitespaces).isEmpty
            ? store.movies
            : store.movies.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
        
        return showOnlyFav ? searched.filter { $0.isFav } : searched
    }
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                
                // nama app
                HStack(spacing: 12) {
                    Image(systemName: "movieclapper.fill")
                        .imageScale(.large)
                        .foregroundStyle(.green)
                    
                    Text("UCFlix")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundStyle(.red)
                }
                .padding(.horizontal)
                
                // search bar
                TextField("Search your movie...", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                
                // toggle fav
                Toggle("Show Favorites Only", isOn: $showOnlyFav)
                    .padding(.horizontal)
                
                // grid card
                ScrollView {
                    LazyVGrid(
                        columns: Array(repeating: GridItem(.flexible()), count: gridColumns),
                        spacing: 16
                    ) {
                        ForEach($store.movies) { $movie in
                            // filter ke fav atau tdk
                            if filteredMovies.contains(where: { $0.id == movie.id }) {
                                NavigationLink {
                                    MovieDetailView(movie: movie)
                                        .environmentObject(store)
                                } label: {
                                    MovieCardView(movie: movie, isFav: $movie.isFav)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .padding(.top)
        }
    }
}

#Preview {
    ContentView()
}
