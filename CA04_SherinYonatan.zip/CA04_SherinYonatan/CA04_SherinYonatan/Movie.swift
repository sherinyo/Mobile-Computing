//
//  Movie.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//
import Foundation

struct Movie: Identifiable, Hashable {
    let id: UUID = UUID()
    let title: String
    let genre: String
    let year: Int
    let posterURL: URL?
    let synopsis: String
    let rating: Double
    var isFav: Bool = false 
}

