//
//  MovieCardView.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCardView: View {
    let movie: Movie
    // binding dan bonus
    @Binding var isFav: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            
            // Gambar Poster
            AsyncImage(url: movie.posterURL) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                Color(.secondarySystemBackground)
                    .overlay(Image(systemName: "film")
                        .font(.largeTitle))
            }
            .frame(height: 180)
            .clipped()
            .cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 4) {
                
                HStack {
                    Text(movie.title)
                        .font(.headline)
                        .lineLimit(1)
                
                    Spacer()
                    
                    Button(action: {
                        isFav.toggle()
                    }) {
                        Image(systemName: isFav ? "heart.fill" : "heart")
                            .foregroundColor(.red)
                    }
                }
                
                
                Text("\(movie.genre) - \(movie.year)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                Label(String(format: "%.1f", movie.rating), systemImage: "star.fill")
                    .font(.subheadline)
                    .foregroundColor(.yellow)
            }
            .padding(10)
        }
        .frame(width: 180, height: 280)
        .background(Color(.systemBackground))
        .cornerRadius(14)
        .shadow(radius: 6, x: 2, y: 4)
    }
}
