//
//  MovieDetailView.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    @EnvironmentObject var store: MovieStore
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                
               // poster
                AsyncImage(url: movie.posterURL) { image in
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(height: 420)
                        .clipped()
                } placeholder: {
                    Color(.systemGray5)
                        .frame(height: 420)
                        .overlay(
                            Image(systemName: "film")
                                .font(.largeTitle)
                        )
                }
                .cornerRadius(10)
                .shadow(radius: 8)
                
                HStack {
                    VStack(alignment: .leading) {
                        Text(movie.title)
                            .font(.title)
                            .bold()
                        Text("\(movie.genre) - \(movie.year)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                Text("Synopsis")
                    .font(.headline)
                Text(movie.synopsis)
                    .font(.subheadline)
                
                Text("Rating: \(String(format: "%.1f", movie.rating))")
                
                NavigationLink("Cast Info") {
                    CastInfoDetailView(movie: movie)
                }
                .font(.subheadline)
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
