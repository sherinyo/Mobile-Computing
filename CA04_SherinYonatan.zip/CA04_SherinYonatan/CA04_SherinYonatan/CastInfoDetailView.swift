//
//  CastInfoDetailView.swift
//  CA04_SherinYonatan
//
//  Created by student on 02/10/25.
//
import SwiftUI

struct CastInfoDetailView: View {
    let movie: Movie
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Cast of \(movie.title)")
                .font(.title2)
                .bold()
            
            Text("Main Actor: Bernard F Kowe")
            Text("Director: Sherin Yonatan") // maaf tidak ada modelnya
            
            Spacer()
        }
        .padding()
        .navigationTitle("Cast Info")
    }
}
