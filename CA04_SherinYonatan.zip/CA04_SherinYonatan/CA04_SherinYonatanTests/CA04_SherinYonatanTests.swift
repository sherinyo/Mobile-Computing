//
//  CA04_SherinYonatanTests.swift
//  CA04_SherinYonatanTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import CA04_SherinYonatan

struct CA04_SherinYonatanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
