//
//  TH03_SherinYonatanApp.swift
//  TH03-SherinYonatan
//
//  Created by student on 29/09/25.
//

import SwiftUI

@main
struct TH03_SherinYonatanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
