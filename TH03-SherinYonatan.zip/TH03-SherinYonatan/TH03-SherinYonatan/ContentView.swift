//
//  ContentView.swift
//  TH03-SherinYonatan
//
//  Created by student on 29/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            locationView()
                .tabItem {
                    Label("Location", systemImage: "mappin.and.ellipse")
                }
            chartView()
                .tabItem {
                    Label("Chart", systemImage: "chart.bar")
                }
            powerView()
                .tabItem {
                    Label("Profile", systemImage: "person.fill")
                }
        }
    }
}

struct HomeView: View {
    var body: some View {
        ZStack {
            VStack(alignment: .leading, spacing: 16) {
                
                // 1
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Good Morning,")
                            .font(.custom("Times New Roman", size: 28))
                            .foregroundColor(.black.opacity(0.7))
                        Text("Sherin")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                    }
                    
                    Spacer()
                    
                    Image("Image")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 80, height: 80)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                }
                .padding(.horizontal)
                
                // 2
                TextField("Search", text: .constant(""))
                    .padding(16)
                    .background(Color.white)
                    .cornerRadius(12)
                    .padding(.horizontal)
                
                // 3
                VStack(spacing: 12) {
                    Text("Today's Goal")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundStyle(.white)
                    
                    HStack(spacing: 16) {
                        TodayGoalCard(
                            icon: "figure.walk",
                            title: "4 Miles",
                            subtitle: "@Thames Route",
                            color: Color.white.opacity(0.1)
                        )
                        TodayGoalCard(
                            icon: "bicycle",
                            title: "2 Miles",
                            subtitle: "@River Lea",
                            color: Color.white.opacity(0.1)
                        )
                    }
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(
                    LinearGradient(colors: [.green, .blue, .pink], startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                .cornerRadius(20)
                .padding(20)
                
                // 4
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        FourCard(icon: "heart.fill", value: "68 Bpm", color: .purple)
                        FourCard(icon: "flame.fill", value: "0 Kcal", color: .orange)
                    }
                    HStack(spacing: 16) {
                        FourCard(icon: "scalemass.fill", value: "73 Kg", color: .green)
                        FourCard(icon: "moon.zzz.fill", value: "6.2 Hr", color: .blue)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
            .frame(width:400)
        }
        .frame(width:400,height:730)
        .background(Color.gray.opacity(0.1).ignoresSafeArea())

    }
}

struct powerView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Ini Profile Page")
                .font(.largeTitle)
                
        }
    }
}

struct locationView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Ini Location Page")
                .font(.largeTitle)
        }
    }
}

struct chartView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Ini Chart Page")
                .font(.largeTitle)
        }
    }
}

struct TodayGoalCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let color: Color

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.white)
            Text(title)
                .font(.headline)
                .foregroundColor(.white)
            Text(subtitle)
                .font(.custom("Times New Roman", size: 12))
                .foregroundColor(.white.opacity(0.8))
        }
        .frame(width: 140, height: 130)
        .background(color)
        .cornerRadius(12)
        .border(Color(.white), width: 0.1)
    }
}

    struct FourCard: View {
        let icon: String
        let value: String
        let color: Color
        
        var body: some View {
                HStack {
                    Image(systemName: icon)
                        .foregroundColor(color)
                        .padding(.top, -30)
                        .font(.system(size: 32))

                    Spacer()

                    Text(value)
                        .font(.system(size: 24))
                        .padding(.top, 40)
                }
                .padding(20)
                .background(Color(.white))
                .cornerRadius(20)
            }
    }

#Preview {
    ContentView()
}

