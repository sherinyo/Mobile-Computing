//
//  TH03_SherinYonatanTests.swift
//  TH03-SherinYonatanTests
//
//  Created by student on 29/09/25.
//

import Testing
@testable import TH03_SherinYonatan

struct TH03_SherinYonatanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
